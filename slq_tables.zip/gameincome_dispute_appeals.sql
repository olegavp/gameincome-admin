create table dispute_appeals
(
    id         char(36)                             not null
        primary key,
    user_id    char(36)                             not null,
    key_id     char(36)                             not null,
    seller_id  char(36)                             not null,
    number     bigint                               not null,
    answered   tinyint(1) default 0                 not null,
    closed_at  datetime                             null,
    created_at datetime   default CURRENT_TIMESTAMP not null,
    updated_at datetime   default CURRENT_TIMESTAMP not null,
    constraint dispute_appeals_seller_id_foreign
        foreign key (seller_id) references sellers (id),
    constraint dispute_appeals_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index key_id_index
    on dispute_appeals (key_id);

create index number_index
    on dispute_appeals (number);

create index seller_id_index
    on dispute_appeals (seller_id);

create index user_id_index
    on dispute_appeals (user_id);

