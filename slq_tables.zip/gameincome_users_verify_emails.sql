create table users_verify_emails
(
    id            char(36)                             not null
        primary key,
    user_id       char(36)                             null,
    user_email    varchar(255)                         null,
    user_name     varchar(100)                         null,
    user_surname  varchar(100)                         null,
    user_avatar   text                                 null,
    user_password varchar(255)                         null,
    code          int                                  null,
    hash          varchar(255)                         null,
    is_verified   tinyint(1) default 0                 not null,
    created_at    datetime   default CURRENT_TIMESTAMP not null,
    updated_at    datetime   default CURRENT_TIMESTAMP not null,
    constraint users_verify_emails_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index code_index
    on users_verify_emails (code);

create index hash_index
    on users_verify_emails (hash);

create index user_email_index
    on users_verify_emails (user_email);

create index user_id_index
    on users_verify_emails (user_id);

create index user_name_index
    on users_verify_emails (user_name);

create index user_surname_index
    on users_verify_emails (user_surname);

create index verified_index
    on users_verify_emails (is_verified);

INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('46867894-029c-42a7-929f-7b0cc6f06f02', null, '456@asd.tu', '123456789', '123456789', null, '$2y$10$kv0y4zyyujjl.T81TsYfmOmxkD3k5iCx/LsUfsX0Es4vtHXVgVQRG', 162546, '$2y$10$x/L9F.EeWXbmlk4.2PuKP.ycJ.qBIe3UIYSb/KKJ4xXnv5x/gSZES', 0, '2021-10-28 06:10:23', '2021-10-28 06:10:23');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('4e8941fb-99f1-411a-9e90-e8ca086fcd9e', null, 'movleks78@gmail.com', 'ttttt', 'tttt', null, '$2y$10$7/N4Km9rX5EAoUngK31axOUTdhbtr1LzFOF2Sd.IpOJ/Dt0wqxOv2', 782547, '$2y$10$Nrp7gBzZwO26sJVp8mECHeq1SDmId9a/G6vJ6a//hYcgYjMH80taO', 0, '2021-10-06 18:57:04', '2021-10-06 18:57:04');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('4f9fa29c-b152-4e14-92ff-cdcf924bcde2', null, 'taly008@yandex.ru', 'test', 'test', null, '$2y$10$W9CbV1cR6YVYy9Axt0zDXuUOP6HoekYRkzzszazmZmt8wnDa9PVWq', 146699, '$2y$10$1YUx2jxrMHnPphOOboUB.eJjZdJuuC1BW.Taskktl5H55QQf7dgu.', 0, '2021-10-16 10:48:31', '2021-10-16 10:48:31');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('7a648d48-59b6-46e7-a2c0-b9cd54bde081', null, 'evgeny_zaika@mail.ru', 'Evgeny', 'Zaika', 'https://sun6-23.userapi.com/s/v1/ig1/_7ox72mtdwbK0-J2okIpFPBrMEkjGcFPqhCTKHJ5vZkLAkFjILSkhwW8LPqt7WzGXV8wRjCu.jpg?size=200x200&quality=96&crop=165,448,1286,1286&ava=1', null, null, '$2y$10$jfBObiHYII82NlHVMJEG9.dvULVhlUPpyVzHoertN7AyY2UZO75Y2', 0, '2021-10-25 11:44:05', '2021-10-25 11:44:05');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('856ec77e-00cc-4efe-b33b-0b264e27465e', null, '456@asd.tu', '123456789', '123456789', null, '$2y$10$qZWFcgF.D1YpY18RLssHne0kftuVAoJ5xzttGpx.aL6rWz6CjLeVO', 747282, '$2y$10$lnGDe6vl.Det989FECAlx.20CrCjaBw5qk.ODP9kP5NDAaqIIjM1O', 0, '2021-10-28 06:10:21', '2021-10-28 06:10:21');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('a461312c-ed37-42b5-bf89-51fe63135a9d', null, 'evgeny_zaika@mail.ru', 'Evgeny', 'Zaika', 'https://sun6-23.userapi.com/s/v1/ig1/_7ox72mtdwbK0-J2okIpFPBrMEkjGcFPqhCTKHJ5vZkLAkFjILSkhwW8LPqt7WzGXV8wRjCu.jpg?size=200x200&quality=96&crop=165,448,1286,1286&ava=1', null, null, '$2y$10$q1DxqfwIuaxjhWXB7eZWiehzT.ajWa8Vc4PHvd4.7JMDOVylLZv8O', 0, '2021-10-25 11:43:58', '2021-10-25 11:43:58');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('b222ac72-3279-434e-babe-ee8d1986fb57', null, 'taly008@yandex.ru', 'test', 'test', null, '$2y$10$GQCALNoyQqo8akQr0BRiKOXa7acQ.yNmUiw8UPK5EtLtHxObukPce', 452398, '$2y$10$3Oa6jE/jQOBh7SezzaRUjeY/CqUeICV0Xwzlr2SdYiw5E9XI09ZLC', 0, '2021-10-16 10:54:53', '2021-10-16 10:54:53');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('c264ca51-5d8b-4cd9-9cef-0d208ca55a5e', null, '456@asd.tu', '123456789', '123456789', null, '$2y$10$1XpzrGtAnm3Wejob9gQXWum4pxuYkxpE/.p1NU/0eLi/wZODJx4rm', 441410, '$2y$10$nwtiosjEaktYO9eKT8VnK..eeKp4i50vjpMJrw/.06F7ug6hFFbue', 0, '2021-10-28 06:10:23', '2021-10-28 06:10:23');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('dad5b061-cc15-4573-b8bb-67f0a4f16533', null, 'movleks78@gmail.com', 'ttttt', 'tttt', null, '$2y$10$nbzn0BjtH61QqumEQ0YQ.epZejrtcsAjLj5adTAdSz7plvZe1dn/S', 704835, '$2y$10$nyRmfpT5DH6tp2Z.RVdO8OjOWfkSjpgY7HqTS/pVk2wQUqa9O/hsO', 0, '2021-10-06 18:57:07', '2021-10-06 18:57:07');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('df430c21-e168-4b96-8ff7-0025f2aa6b9d', null, '456@asd.tu', '123456789', '123456789', null, '$2y$10$.vELJ73h1cYvJGVb0w2A8OCDlA38Dy.UvvAmcbgnvUI/dIxeA9FPC', 664468, '$2y$10$EuFZ5REDXf1sJ71xUCps0ebIL3rrGEBsliup7kyPi3RhTvNHOVoLq', 0, '2021-10-28 06:10:18', '2021-10-28 06:10:18');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('e2cc37b5-ce1a-4584-91e4-1281d3cad18b', null, 'taly008@yandex.ru', 'Vitaly', 'Tretyakov', 'https://sun6-23.userapi.com/s/v1/ig2/C6-39Fi5CjivqV90HQ0YVEDtOlpargU_RisisgniPSN5552crFkYjVUEC5Du9veuQNv8F_OBdXv7x69zfG81naoa.jpg?size=200x200&quality=96&crop=89,0,401,401&ava=1', null, null, '$2y$10$sN8pjpq1i6TG/PS/aNR0B.lLceGKeul2qyBmQQg4vtC02ziV7Wmsi', 0, '2021-10-16 11:16:40', '2021-10-16 11:16:40');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('e6050cae-6af2-4645-b91e-ece280017784', null, '456@asd.tu', '123456789', '123456789', null, '$2y$10$2pUvTf8kADINbKAOpYlmg.OGAmrr9jJLgdYy0go2tk/jEEQ/Q/NY2', 348618, '$2y$10$KO5m9Zq/QqdnIitsx6h16OeAwMR6pdZjDsSbe7TkIGA.2jGUjVAoi', 0, '2021-10-28 06:10:22', '2021-10-28 06:10:22');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('e6926670-4761-4ec8-923a-6cc938faedf5', null, 'taly008@yandex.ru', 'Vitaly', 'Tretyakov', 'https://sun6-23.userapi.com/s/v1/ig2/C6-39Fi5CjivqV90HQ0YVEDtOlpargU_RisisgniPSN5552crFkYjVUEC5Du9veuQNv8F_OBdXv7x69zfG81naoa.jpg?size=200x200&quality=96&crop=89,0,401,401&ava=1', null, null, '$2y$10$/aXHhLs4sMqexzGhIIlJju8F4ju9seugyluGo4yUlz3IXp/nghAb2', 0, '2021-10-16 11:16:17', '2021-10-16 11:16:17');
INSERT INTO gameincome.users_verify_emails (id, user_id, user_email, user_name, user_surname, user_avatar, user_password, code, hash, is_verified, created_at, updated_at) VALUES ('ebd7c9c7-5f2f-41b2-809c-1b21d2bcc64f', null, 'taly008@yandex.ru', 'test', 'test', null, '$2y$10$bRjHi6J8aS7cm3ywsYO8T.n.SNkedoLxc36C2scpOCgCuXIMO3aqa', 924795, '$2y$10$h2QXbGIbOInyEkJaePSGPeLn1rDwOSh6GnbT5zKXm3uad2eBQnSY2', 0, '2021-10-16 10:48:21', '2021-10-16 10:48:21');