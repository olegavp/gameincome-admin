create table general_appeals
(
    id         char(36)                             not null
        primary key,
    user_id    char(36)                             not null,
    number     bigint                               not null,
    theme      varchar(255)                         not null,
    answered   tinyint(1) default 0                 not null,
    closed_at  datetime                             null,
    created_at datetime   default CURRENT_TIMESTAMP not null,
    updated_at datetime   default CURRENT_TIMESTAMP not null,
    constraint general_appeals_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index number_index
    on general_appeals (number);

create index theme_index
    on general_appeals (theme);

create index user_id_index
    on general_appeals (user_id);

