create table main_page_inserts
(
    id                char(36)     not null
        primary key,
    over_insert       varchar(100) null,
    small_description varchar(100) null,
    description       varchar(200) null,
    text_on_button    varchar(30)  null,
    link              varchar(255) null,
    background        varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.main_page_inserts (id, over_insert, small_description, description, text_on_button, link, background) VALUES ('06eddf36-1cf2-4e0d-a9c4-3dce0faeed89', 'Grand Theft Auto', 'Grand Theft Auto V', 'В издание Grand Theft Auto V: Premium Edition входят полный сюжетный режим GTAV, Grand Theft Auto Online и все ранее выпущенные материалы и обновления', 'купить сейчас', 'google.com', 'https://api.gameincome.com/storage/backgrounds/image 45_1627933913.png');
INSERT INTO gameincome.main_page_inserts (id, over_insert, small_description, description, text_on_button, link, background) VALUES ('16669338-b00e-44c0-a3a3-cbca83de06fb', 'FORTNITE', 'Лисица-охотница присоединится к отряду Fortnite в феврале', 'В попытке обогнать само время к отряду Fortnite присоединяется новая хитроумная воительница.', 'ПОДРОБНЕЕ', 'google.com', 'https://api.gameincome.com/storage/backgrounds/1 86_1627340860.png');
INSERT INTO gameincome.main_page_inserts (id, over_insert, small_description, description, text_on_button, link, background) VALUES ('d2c13f7c-47f6-4449-ba43-f9f373157013', 'CYBERPUNK 2077', 'Cyberpunk 2077', 'Приключенческая ролевая игра, действие которой происходит в мегаполисе Найт-Сити, где власть, роскошь и модификации тела ценятся выше всего.', 'узнать больше', 'google.com', 'https://api.gameincome.com/storage/backgrounds/2 862_1627933789.png');