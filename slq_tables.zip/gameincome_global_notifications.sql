create table global_notifications
(
    id          char(36)                           not null,
    type        varchar(100)                       null,
    name        varchar(100)                       null,
    description varchar(250)                       null,
    created_at  datetime default CURRENT_TIMESTAMP not null,
    updated_at  datetime default CURRENT_TIMESTAMP not null
)
    collate = utf8mb4_unicode_ci;

create index id_index
    on global_notifications (id);

create index type_index
    on global_notifications (type);

