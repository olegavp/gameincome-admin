create table transactions
(
    id         char(36)                           not null
        primary key,
    user_id    char(36)                           not null,
    product    varchar(255)                       not null,
    product_id char(36)                           not null,
    operation  varchar(255)                       not null,
    action     tinyint(1)                         not null,
    available  tinyint(1)                         not null,
    amount     bigint                             not null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint transactions_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index action_index
    on transactions (action);

create index available_index
    on transactions (available);

create index operation_index
    on transactions (operation);

create index product_id_index
    on transactions (product_id);

create index product_index
    on transactions (product);

create index user_id_index
    on transactions (user_id);

INSERT INTO gameincome.transactions (id, user_id, product, product_id, operation, action, available, amount, created_at, updated_at) VALUES ('1153be12-fd9a-45e9-a06b-3f4ba1ddfba1', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'Подарочный код «GameInCome»', 'd513a6be-2805-11ec-9621-0242ac130002', 'Подарочный код', 1, 1, 1000000, '2021-10-08 10:02:11', '2021-10-08 10:02:11');
INSERT INTO gameincome.transactions (id, user_id, product, product_id, operation, action, available, amount, created_at, updated_at) VALUES ('613f902d-f8df-460c-a9a6-7008831b1ae3', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'Подарочный код «GameInCome»', 'fd33c0fc-2805-11ec-9621-0242ac130002', 'Подарочный код', 1, 1, 250000, '2021-10-08 10:02:11', '2021-10-08 10:02:11');