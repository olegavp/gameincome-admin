create table users_ip
(
    id           char(36)                             not null
        primary key,
    user_id      char(36)                             null,
    token_id     varchar(255)                         null,
    ip           varchar(255)                         null,
    device       varchar(255)                         null,
    browser      varchar(255)                         null,
    hash         varchar(255)                         null,
    confirmed    tinyint(1) default 0                 not null,
    confirmed_at datetime                             null,
    deleted_at   datetime                             null,
    created_at   datetime   default CURRENT_TIMESTAMP not null,
    updated_at   datetime   default CURRENT_TIMESTAMP not null,
    constraint users_ip_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index confirmed_at_index
    on users_ip (confirmed_at);

create index confirmed_index
    on users_ip (confirmed);

create index deleted_at_index
    on users_ip (deleted_at);

create index hash_index
    on users_ip (hash);

create index ip_index
    on users_ip (ip);

create index token_id_index
    on users_ip (token_id);

create index user_id_index
    on users_ip (user_id);

INSERT INTO gameincome.users_ip (id, user_id, token_id, ip, device, browser, hash, confirmed, confirmed_at, deleted_at, created_at, updated_at) VALUES ('571209f4-34c8-444f-bb07-d6923ba7795b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', '1', '127.0.0.1', null, null, null, 1, null, null, '2021-09-20 21:41:29', '2021-09-20 21:41:29');
INSERT INTO gameincome.users_ip (id, user_id, token_id, ip, device, browser, hash, confirmed, confirmed_at, deleted_at, created_at, updated_at) VALUES ('571209f4-34c8-444f-bb07-d6923ba7795c', '0e2090f0-d1da-4e55-ad25-0af0d2e85037', '2', '127.0.0.1', null, null, null, 1, null, null, '2021-09-20 21:41:29', '2021-09-20 21:41:29');
INSERT INTO gameincome.users_ip (id, user_id, token_id, ip, device, browser, hash, confirmed, confirmed_at, deleted_at, created_at, updated_at) VALUES ('6fec8a37-05bf-4aa8-bb42-fbf46531367f', '9250f2fb-924b-4f02-9a46-9be311f45213', '3', '127.0.0.1', null, null, null, 1, null, null, '2021-09-20 21:41:29', '2021-09-20 21:41:29');