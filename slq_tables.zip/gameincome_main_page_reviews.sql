create table main_page_reviews
(
    id        char(36) not null
        primary key,
    review_id char(36) not null,
    constraint main_page_reviews_review_id_foreign
        foreign key (review_id) references reviews (id)
)
    collate = utf8mb4_unicode_ci;

create index review_id_index
    on main_page_reviews (review_id);

INSERT INTO gameincome.main_page_reviews (id, review_id) VALUES ('64a3698c-26a2-11ec-9621-0242ac130002', '54db6ac8-26a1-11ec-9621-0242ac130002');
INSERT INTO gameincome.main_page_reviews (id, review_id) VALUES ('64a3666c-26a2-11ec-9621-0242ac130002', '54db6fc8-26a1-11ec-9621-0242ac130002');
INSERT INTO gameincome.main_page_reviews (id, review_id) VALUES ('64a3689c-26a2-11ec-9621-0242ac130002', 'e8a8a92e-26a0-11ec-9621-0242ac130002');