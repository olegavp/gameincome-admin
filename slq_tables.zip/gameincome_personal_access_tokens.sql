create table personal_access_tokens
(
    id             bigint unsigned auto_increment
        primary key,
    tokenable_type varchar(255) not null,
    tokenable_id   varchar(255) not null,
    name           varchar(255) not null,
    token          varchar(64)  not null,
    abilities      text         null,
    last_used_at   timestamp    null,
    created_at     timestamp    null,
    updated_at     timestamp    null,
    constraint personal_access_tokens_token_unique
        unique (token)
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) VALUES (1, 'App\\Models\\User', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'token', 'arE4qBTGTbnHNZP7m9Tsi1xXKeh7VPNCYXPlHTad', '["*"]', '2021-11-01 10:53:11', '2021-09-04 14:35:14', '2021-11-01 10:53:11');
INSERT INTO gameincome.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) VALUES (2, 'App\\Models\\User', '0e2090f0-d1da-4e55-ad25-0af0d2e85037', 'token', 'arE4qBTGTbnHNZP7m9Tsi1xXKeh7VPNCYXPlHTaE', '["*"]', '2021-09-19 15:03:03', '2021-09-04 14:35:14', '2021-09-19 15:03:03');
INSERT INTO gameincome.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) VALUES (3, 'App\\Models\\User', '9250f2fb-924b-4f02-9a46-9be311f45213', 'token', 'arE4qBTGTbnHNZP7m9Tsi1xXKeh7VPNCYXPlHTaQ', '["*"]', '2021-09-19 15:03:03', '2021-09-04 14:35:14', '2021-09-19 15:03:03');