create table categories
(
    id   char(36)     not null
        primary key,
    name varchar(255) not null,
    slug varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.categories (id, name, slug) VALUES ('05159f73-90bb-474c-a974-de30826e2e32', 'Симуляторы', 'simulyatory');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('0f830437-746d-4054-a98a-7379912c91de', 'Анимация и моделирование', 'animaciya-i-modelirovanie');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('18a724f8-0fb2-44f8-a3b8-37ac2ecd7284', 'Дизайн и иллюстрация', 'dizain-i-illyustraciya');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('1f9840e2-8993-4d92-a2ea-a4ba42444fee', 'Приключенческие игры', 'priklyucenceskie-igry');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('32ac3152-1d04-4400-8898-54d4e265f5b5', 'Ранний доступ', 'rannii-dostup');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('399587ba-0be7-43a4-a2df-14e9fb9aa5b3', 'Инди', 'indi');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('3c4e50b3-f2b7-489f-b21b-8d2693b493bf', 'Гонки', 'gonki');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('430674d0-b42a-4b9c-b02d-4dd8bb0d36ae', 'Обработка фото', 'obrabotka-foto');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('440821b1-f773-48ea-be4b-6c7951968ecc', 'Стратегии', 'strategii');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('465d7664-892b-4307-870e-368b6cb9d9cc', 'Бесплатно', 'besplatno');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('54bd8e39-ed2d-452b-a7ed-fb0515c1655c', 'Спортивные игры', 'sportivnye-igry');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('8b0eedf7-b230-4041-8d90-619c9145b7c4', 'Утилиты', 'utility');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('8fa91de4-dc32-42a5-a4bb-ae9eabfda639', 'Казуальные игры', 'kazualnye-igry');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('d96fcce9-3b22-4fb3-92dd-06f7665fdea4', 'Ролевые игры', 'rolevye-igry');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('f9159b8c-a7d4-44d1-a561-df6c64c47303', 'Многопользовательские игры', 'mnogopolzovatelskie-igry');
INSERT INTO gameincome.categories (id, name, slug) VALUES ('fd751c15-aa2b-44b2-8854-d982e5d0d41e', 'Экшены', 'ekseny');