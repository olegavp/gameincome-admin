create table main_page_headers_link
(
    id   char(36)    not null
        primary key,
    name varchar(8)  not null,
    slug varchar(15) not null,
    constraint main_page_headers_link_name_unique
        unique (name),
    constraint main_page_headers_link_slug_unique
        unique (slug)
)
    collate = utf8mb4_unicode_ci;

