create table item_service
(
    id         char(36)     not null
        primary key,
    service_id varchar(255) not null,
    item_id    varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

create index item_id_index
    on item_service (item_id);

create index service_id_index
    on item_service (service_id);

INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('00a4649d-209c-43de-a4d7-7b9b28f41b7d', '94844e76-7198-4d54-b139-4babb4558dbb', '041b1016-f72b-4351-bd37-bd9f3db8b553');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('02d24379-ed27-491c-aaa2-347f5f663882', '94844e76-7198-4d54-b139-4babb4558dbb', 'e492c9d6-1e9b-4446-919b-d603d5520665');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('02ee7a95-6582-4ec5-8761-88f1af4baca8', '94844e76-7198-4d54-b139-4babb4558dbb', 'dc4482c0-cbc5-49d6-9fd9-322fc7728181');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('032ccdd1-a892-4251-99c6-098b6ff37825', '94844e76-7198-4d54-b139-4babb4558dbb', 'beae0119-c470-4e59-874b-778a38794e0a');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('056cd01e-c342-4d1a-92d6-98a046300920', '94844e76-7198-4d54-b139-4babb4558dbb', 'cdc884b7-59dd-44bf-b3a1-be520b9d719c');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('06bcb778-82fa-4b74-a4e6-6d32954b7f06', '94844e76-7198-4d54-b139-4babb4558dbb', '4c366296-6051-488a-83af-f8110d2f9599');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('0c786b04-656d-49c3-827e-eb41f3ee8947', '94844e76-7198-4d54-b139-4babb4558dbb', '2c4e2d1e-014c-4ba2-846f-925227cd8095');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('0d8658a7-3d6a-4765-aa0a-5387038132e7', '94844e76-7198-4d54-b139-4babb4558dbb', '8abcf07d-5e6a-4da9-8c5c-c97fe8bbc3e7');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('0df8b01a-bfa6-488e-84ba-9a0675ce8c51', '94844e76-7198-4d54-b139-4babb4558dbb', '98b56f15-c951-408a-82b5-c93c48f1c3f1');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('0e0894fb-072f-425e-8614-0d5633d45f04', '94844e76-7198-4d54-b139-4babb4558dbb', '4c27e688-8691-478a-8e4b-f35124c01f32');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('11ebae01-bed8-4851-9b7b-387af6984467', '94844e76-7198-4d54-b139-4babb4558dbb', '7ff8cc77-0975-4313-865a-4cf7f0620041');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('146456d2-f19f-49ef-be2e-006e5c17f60c', '94844e76-7198-4d54-b139-4babb4558dbb', '18651a01-6765-42bb-b10e-428861999f40');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('17e8ac95-4654-42cf-b99f-aeb5781dc09f', '94844e76-7198-4d54-b139-4babb4558dbb', 'b389c37c-7ce5-471b-a310-d9fef5f41e62');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('197b50fe-5392-4273-85f7-6abf8ff4dad9', '94844e76-7198-4d54-b139-4babb4558dbb', 'ba446a61-a1e0-408a-b37e-c97ddb653391');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('1e07c2f7-4a76-4224-9c97-1372901c7971', '94844e76-7198-4d54-b139-4babb4558dbb', 'd7185060-5342-4087-a461-dddf4eeff398');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('206a4ccc-e434-4e1c-bd03-0d2c3d6c1a73', '94844e76-7198-4d54-b139-4babb4558dbb', '338176b2-90dd-4430-9942-34ed8435b3f3');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('25035f1e-35cf-4b1a-9ec6-68eef8b80301', '94844e76-7198-4d54-b139-4babb4558dbb', '26d8578c-b81a-4a18-850f-db163dc17b7f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('27dfba38-a8d6-45e7-9ff5-68a486c19eae', '94844e76-7198-4d54-b139-4babb4558dbb', 'e599ac2b-f945-49f4-80d1-e291755d88d9');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('2888d3b4-79b1-4bb6-afd9-3e626aabe9e7', '94844e76-7198-4d54-b139-4babb4558dbb', 'e1d4c646-1960-46f1-b0d5-fb89553d7d41');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('2ba521f5-6fda-47eb-9064-f202820a545c', '94844e76-7198-4d54-b139-4babb4558dbb', 'e8e37c54-0a45-47ce-b332-83f85e728799');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('2c469031-80ce-4500-a511-d830c38c4e2e', '94844e76-7198-4d54-b139-4babb4558dbb', 'e6ba88e3-fbe5-4ac2-b24e-a9261c7fe5d8');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('30ac9a27-94b3-4044-9111-415e6e48614b', '94844e76-7198-4d54-b139-4babb4558dbb', 'c8eb9923-087d-4b57-9065-ba21a705cb34');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('36648ce5-4700-4a78-9192-9995662d8147', '94844e76-7198-4d54-b139-4babb4558dbb', '01debaa6-9743-49ec-a728-1f4fc0385ee7');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('3a637f5f-6375-4218-b82a-483606f8f319', '94844e76-7198-4d54-b139-4babb4558dbb', '598fb139-58e6-4583-b695-e4073a98fad4');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('3c7c1255-5d6f-4bf2-b198-da85ae816f25', '94844e76-7198-4d54-b139-4babb4558dbb', '82167831-da91-488a-9526-f7bf2dad8f6f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('3e0e6c08-efaf-4eb9-9d32-80ff0f712f40', '94844e76-7198-4d54-b139-4babb4558dbb', 'c9f79ae2-9bcc-4860-bc1a-3ae84079450a');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('3e54a2c3-962a-4117-9a3e-540122fac45c', '94844e76-7198-4d54-b139-4babb4558dbb', '5941357a-5b88-48cc-8e50-09f25d5dab4b');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('40d59392-d776-41f8-b7f8-5d1ccc9b3cff', '94844e76-7198-4d54-b139-4babb4558dbb', 'cc7c7429-cfbc-4b7f-83ca-619d6fe0e43d');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('42d683de-831d-4596-8a2d-483d76fb29ef', '94844e76-7198-4d54-b139-4babb4558dbb', '180b7656-03ef-4bb4-8443-f36148a13cbb');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('44a7bb70-8b25-447c-8fa2-9ebeb85a1a2c', '94844e76-7198-4d54-b139-4babb4558dbb', 'c5e144db-2f27-4a3c-a75f-66048a1edd32');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('45f5bb35-1817-4062-a74f-bf8bc226d757', '94844e76-7198-4d54-b139-4babb4558dbb', 'd9c29ed4-36bf-451a-b00f-e2765c55a837');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('477297fd-f3ae-40aa-9647-10eaca8e722d', '94844e76-7198-4d54-b139-4babb4558dbb', '525e81de-2581-4243-8eeb-a83090ff00b9');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('4a11aa09-f6cd-4f1c-a3c5-2cd86e35d17f', '94844e76-7198-4d54-b139-4babb4558dbb', '4bef6994-00e7-482e-bda3-dbf32450d44e');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('4b5c5a1d-9c0c-4e64-8c5e-9a53885ae353', '94844e76-7198-4d54-b139-4babb4558dbb', 'ab6b3c5a-d1c4-4076-b789-846bb72b5e3e');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('51684732-5818-4e66-82c5-2df8d5850f70', '94844e76-7198-4d54-b139-4babb4558dbb', 'd68d3565-74fa-4243-ade7-d6f0a386925e');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('5631c4b8-8408-4f4c-bd76-2068b56de130', '94844e76-7198-4d54-b139-4babb4558dbb', '0eda5e5e-89ad-490f-b8a4-be2adf59a348');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('59dcba5d-8f8c-45d7-b3cc-a698ccd0db79', '94844e76-7198-4d54-b139-4babb4558dbb', '3712f456-5da2-4195-a087-a26eaa54608d');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('5a64f478-1c46-40c3-a777-5491456f69c5', '94844e76-7198-4d54-b139-4babb4558dbb', '44e540ed-ef0c-49ff-8f2c-236ece14190b');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('5e5e36e7-70fc-4bc3-8af5-239dd902c9b7', '94844e76-7198-4d54-b139-4babb4558dbb', '2e8d9bb3-375c-47ef-9fa5-c9a4d59528f4');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('5f7844ef-94c8-4f02-8b76-1a5fdbe1bf50', '94844e76-7198-4d54-b139-4babb4558dbb', '852eb07f-a62b-4263-b6d1-cd210d1982ea');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('61597140-9e88-4ed3-a54e-efcd9019738b', '94844e76-7198-4d54-b139-4babb4558dbb', 'e0f5047b-8809-444e-a21a-ba1958031393');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('635d9690-1df6-43a6-ba2d-63b4fca0a853', '94844e76-7198-4d54-b139-4babb4558dbb', '2ed2edf7-5792-49ad-9533-489319056dc4');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('66fca33a-7586-4ba8-a1b1-e53f6ea6c87f', '94844e76-7198-4d54-b139-4babb4558dbb', '12be8262-6f90-4ed6-ab85-94ba53cae34d');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('6bc3e609-9964-4f4f-8d38-cbb4825d1b5b', '94844e76-7198-4d54-b139-4babb4558dbb', '24017336-a11b-43ce-b201-babcf10545e8');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('6bf63039-1d89-4a1e-ae5c-bc8ef67cdef2', '94844e76-7198-4d54-b139-4babb4558dbb', 'c71acdef-15f2-461e-b40a-d0c3dab8b8e1');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('73fd7aa6-1c4c-4d93-97e0-9e18e11a15b1', '94844e76-7198-4d54-b139-4babb4558dbb', '0bfe462c-1027-4a04-80aa-5d98e2892099');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('74557150-9166-4d06-8e0d-25cf292cc755', '94844e76-7198-4d54-b139-4babb4558dbb', '1692c6cf-0b3d-4f5a-aeda-75a8f8b6bd5f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('753cab1e-1987-43ff-b829-4448c2aa552c', '94844e76-7198-4d54-b139-4babb4558dbb', 'b6c26889-98ac-410b-b847-67b7c0a521d4');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('77bb636f-599e-439d-8ff6-993c98b33c7c', '94844e76-7198-4d54-b139-4babb4558dbb', 'f284c848-9812-44fd-91a7-ba091f360a79');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('7b2d1115-4e89-44dd-ad88-05088d614366', '94844e76-7198-4d54-b139-4babb4558dbb', '7e3be834-ad65-489d-867b-b897db0780a3');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('7ff8ea95-d9eb-4f99-b660-e9d26110cbcd', '94844e76-7198-4d54-b139-4babb4558dbb', 'a963876f-3b7f-4f4c-b66b-38221dbb520b');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('80806a4c-eda3-4a94-8c07-5dcb3176b3de', '94844e76-7198-4d54-b139-4babb4558dbb', '245e6e60-552f-4556-b8cf-7bcfd773ba61');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('82c2a028-5b73-470a-938e-e5e6bd59963f', '94844e76-7198-4d54-b139-4babb4558dbb', '632d222b-30e5-4d9d-b5aa-52b339455d7e');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('834d5fa8-f80e-4d0e-9141-c58ab0bd44da', '94844e76-7198-4d54-b139-4babb4558dbb', '272bcfa5-4733-464f-bee4-c4e62d14a30f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('848fb73b-d4c0-4fe8-96e9-5617fce7eb39', '94844e76-7198-4d54-b139-4babb4558dbb', 'fb85bbdc-1555-4f42-bbed-39d579c34275');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('8b652b59-adf1-4ce2-b2ad-94213e217d80', '94844e76-7198-4d54-b139-4babb4558dbb', '979420b5-94f2-4bfe-a2ca-0b5ec4afb119');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('8ec22a6d-fa34-406d-816d-9799f7929dcb', '94844e76-7198-4d54-b139-4babb4558dbb', '00fe3a62-cf9c-49fb-a5e8-186da63bd818');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('936b4133-07d2-445d-a86f-4542f99ad6fb', '94844e76-7198-4d54-b139-4babb4558dbb', '8dff6ed7-95d5-44e0-bbf9-b13e1cdf7f3e');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('944b6345-6e8a-4d51-b971-f737faf9d828', '94844e76-7198-4d54-b139-4babb4558dbb', 'ae5fbe4c-21a3-4538-a7f0-469dbeb87fa8');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('96e24feb-0cd7-4f45-84b9-2ada15e4119e', '94844e76-7198-4d54-b139-4babb4558dbb', 'd6a40206-9081-4c43-b240-2d81477210e3');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('989190c4-88a1-4aa6-81e2-56dc03cda9e0', '94844e76-7198-4d54-b139-4babb4558dbb', 'fd5b07a3-cd6f-4523-b81d-94e454e91eea');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('99e31062-79ef-4b93-b81d-1e6ca3cda697', '94844e76-7198-4d54-b139-4babb4558dbb', '24bcefd1-ac57-40c0-b514-c301f7f35b51');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9a1e5130-36d8-498e-ac78-fd23e92aff6a', '94844e76-7198-4d54-b139-4babb4558dbb', 'e37f0062-0d18-4467-a110-659b495b2305');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9a996a3f-8982-4d67-a1e2-02f3c231d861', '94844e76-7198-4d54-b139-4babb4558dbb', 'ee664413-927f-4e07-a6c3-175f27b27902');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9bf58f7b-8392-4ea3-99e1-d899f9ae8825', '94844e76-7198-4d54-b139-4babb4558dbb', '45121d96-5264-4059-8554-476b6ca4d9ae');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9cc9b112-c6c4-4c5a-952b-2559ba9a9a6e', '94844e76-7198-4d54-b139-4babb4558dbb', '64fdb6b2-edb0-43f2-a5b5-bb3b433a76f5');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9d25ab3b-f0cd-45c6-b5d7-73aabe5b38c8', '94844e76-7198-4d54-b139-4babb4558dbb', 'd243e30d-a33a-454f-8929-22c68de2e473');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9ea2ba9b-2c40-4f66-a8eb-eb7a13ae171e', '94844e76-7198-4d54-b139-4babb4558dbb', 'e849cd7b-4beb-46e6-93cc-cce27fb90f9f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9f3cb0d5-82ee-41bc-9259-482b41be4c39', '94844e76-7198-4d54-b139-4babb4558dbb', '87c7d295-f887-4513-a7ef-54bcfc9bdddf');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('9fddaa0e-5e20-44fe-a27a-28db626e86e7', '94844e76-7198-4d54-b139-4babb4558dbb', 'c0b51af0-ad5f-474d-8a41-107d11b4dfa4');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('a173eed8-0c82-49b7-b967-b88d5b97fdae', '94844e76-7198-4d54-b139-4babb4558dbb', '0f7be640-823b-4092-8bf1-4168b802f84d');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('a372bca0-1ee4-4df4-bc1f-64f3bae1c18f', '94844e76-7198-4d54-b139-4babb4558dbb', '873ea29d-8a19-4cca-99e2-1665c420a398');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('a55a21dd-c1a4-4e61-be37-ccf747b1fb72', '94844e76-7198-4d54-b139-4babb4558dbb', '092bc317-e91e-44cb-93d8-1e8c9167c5de');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('b628a8ec-2e0d-49c3-b8d5-851409794b29', '94844e76-7198-4d54-b139-4babb4558dbb', '5d2e8162-4d96-4109-8b1f-828cbfedfba1');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('beb32ba5-1114-4029-838a-cba0e0b05c85', '94844e76-7198-4d54-b139-4babb4558dbb', '1598af1a-451d-499f-a9ad-7f1d68c5612a');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('bf5523ec-df70-4c28-a7fd-2fd6cf6d1ff8', '94844e76-7198-4d54-b139-4babb4558dbb', '5ae0489e-f787-417d-9cb0-bb10ddccec7f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('c1da840e-ea12-4b1d-821e-7193ed9cb9a5', '94844e76-7198-4d54-b139-4babb4558dbb', 'b4abcc68-d65c-4551-ba0d-3021eef0870f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('c84d8e3e-fd80-44d3-8324-be99f7eccd22', '94844e76-7198-4d54-b139-4babb4558dbb', 'b854d2bf-bc3b-4cab-aa52-3b9fd974f52a');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('c8ea0418-89ab-40bf-9b39-5a990f9072ce', '94844e76-7198-4d54-b139-4babb4558dbb', 'b091d674-3cce-4c22-9f89-22ee96b31410');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('cbf611b0-afc8-46df-b553-ac3e1de2793f', '94844e76-7198-4d54-b139-4babb4558dbb', 'b0177eaf-2a54-4b33-84b2-79a31365b5e5');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('ce03570e-1316-4fb0-af1a-05a86a9fd07e', '94844e76-7198-4d54-b139-4babb4558dbb', 'c21db2ba-0a02-403b-9988-340f4b38c3a5');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('d0383fbc-1464-4444-89e1-bd8e1d001a43', '94844e76-7198-4d54-b139-4babb4558dbb', '593ece10-8cd0-4618-a881-0a6f2afc0059');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('d07ddcb7-b458-4302-a6a8-463d943c40e0', '94844e76-7198-4d54-b139-4babb4558dbb', 'fb67c151-2add-4b36-af75-00c98672d310');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('d1802d57-90b9-4b7b-938f-9cbdfbd1662e', '94844e76-7198-4d54-b139-4babb4558dbb', '9ef34eec-555b-46d4-9116-c38e1caf7ba8');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('d583aaef-64fd-431c-afcc-1e390304a120', '94844e76-7198-4d54-b139-4babb4558dbb', '6de7bfd1-43e6-4781-aee8-5123c02dbb2f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('da4fd988-93e2-4b50-a714-2d437e297546', '94844e76-7198-4d54-b139-4babb4558dbb', '37a3d4f3-624c-493d-9499-f77a6dedc238');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('db55188c-c2e5-4145-b05d-7437136924ca', '94844e76-7198-4d54-b139-4babb4558dbb', '7be099c9-e800-4aa1-ab42-79038f3dbe71');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('df7f4565-03a6-4250-997e-1c81937de1f0', '94844e76-7198-4d54-b139-4babb4558dbb', 'e6c574e5-4cd7-4f81-ae0f-01ece288521f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('e4f6990c-1774-4b0d-9872-046ec3148c57', '94844e76-7198-4d54-b139-4babb4558dbb', 'eb3ca8b7-24d9-4cdf-bfb6-f5fd630a48de');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('e69fbbb6-1a44-470f-9d2e-28fc88240d0a', '94844e76-7198-4d54-b139-4babb4558dbb', '338b87bc-fca9-4fc6-91e2-13387e64368b');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('e6b444f8-2858-4b16-b959-b5fa93d29902', '94844e76-7198-4d54-b139-4babb4558dbb', '24cf314a-1881-49a8-b385-3ebd5068636c');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('e906fca3-3996-47c9-93df-1e3a82fe9cfc', '94844e76-7198-4d54-b139-4babb4558dbb', '58c66729-a531-4fa0-9f9f-4af4432825e7');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('eaf19d8a-8f27-4173-8aa8-657b5371ce69', '94844e76-7198-4d54-b139-4babb4558dbb', 'be150760-f47d-4ad8-8d97-341ea41bca4f');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('eb25656d-f6bd-41e0-b88a-b82fcb54d4d2', '94844e76-7198-4d54-b139-4babb4558dbb', 'f60a2504-f5ee-47af-b713-1ff14f5ce273');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('f257f30e-b8d7-4527-a2e3-14b91468d6b9', '94844e76-7198-4d54-b139-4babb4558dbb', 'fe4216e0-d2a4-4a07-820f-3358624a267c');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('f442f76b-0e9a-477a-8fd0-56a32be2e324', '94844e76-7198-4d54-b139-4babb4558dbb', '60fac456-e39c-49bd-8eec-9e71ef246bf3');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('f6251b8a-1563-494e-a875-d79c63a18189', '94844e76-7198-4d54-b139-4babb4558dbb', '9c21daf4-93da-45f6-9eed-c2b660284875');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('f6fa4995-11b0-40d1-b89e-7688e3d23098', '94844e76-7198-4d54-b139-4babb4558dbb', '1f2f0e14-8a7d-4c40-a832-0b59d080d772');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('f794af1e-4f9e-4eb3-8b12-5e5d43863f6b', '94844e76-7198-4d54-b139-4babb4558dbb', 'af04f107-ab57-4a59-a98f-acfe67536d6a');
INSERT INTO gameincome.item_service (id, service_id, item_id) VALUES ('fccff577-4f0a-4884-a105-dd7d4edfb462', '94844e76-7198-4d54-b139-4babb4558dbb', '12c65d61-ead6-4e59-bd9b-1483e5ecd133');