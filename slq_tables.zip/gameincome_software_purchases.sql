create table software_purchases
(
    id         char(36)                           not null
        primary key,
    user_id    char(36)                           not null,
    seller_id  char(36)                           not null,
    key_id     char(36)                           not null,
    item_id    char(36)                           not null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint software_purchases_item_id_foreign
        foreign key (item_id) references software (id),
    constraint software_purchases_key_id_foreign
        foreign key (key_id) references software_keys (id),
    constraint software_purchases_seller_id_foreign
        foreign key (seller_id) references sellers (id),
    constraint software_purchases_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index item_id
    on software_purchases (item_id);

create index key_id_index
    on software_purchases (key_id);

create index seller_id_index
    on software_purchases (seller_id);

create index user_id_index
    on software_purchases (user_id);

