create table services
(
    id         char(36)     not null
        primary key,
    name       varchar(255) not null,
    slug       varchar(255) not null,
    background varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.services (id, name, slug, background) VALUES ('68924b89-798f-418a-904f-2693533f5518', 'Blizard', 'blizzard', 'https://api.gameincome.com/storage/backgrounds/icons8-battle.net_1627219352.svg');
INSERT INTO gameincome.services (id, name, slug, background) VALUES ('86e72a41-4eaf-460c-a8bc-f6e9187742b8', 'Nintendo eShop', 'nintendo-e-shop', 'https://api.gameincome.com/storage/backgrounds/icons8-nintendo-switch-logo_1627219368.svg');
INSERT INTO gameincome.services (id, name, slug, background) VALUES ('94844e76-7198-4d54-b139-4babb4558dbb', 'Steam', 'steam', 'https://api.gameincome.com/storage/backgrounds/iconmonstr-steam-4_1627218637.svg');
INSERT INTO gameincome.services (id, name, slug, background) VALUES ('94ec4980-b417-424b-b0f3-97512938aea8', 'Epic Games', 'epic-games', 'https://api.gameincome.com/storage/backgrounds/icons8-epic-games_1627219329.svg');
INSERT INTO gameincome.services (id, name, slug, background) VALUES ('a3d9eea7-5202-4150-a32d-8f5f939e5fdf', 'PlayStation Store', 'playstation-store', 'https://api.gameincome.com/storage/backgrounds/icons8-playstation_1627219235.svg');
INSERT INTO gameincome.services (id, name, slug, background) VALUES ('b28677a8-7a49-4b14-8760-8d58a6d644c5', 'Origin', 'origin', 'https://api.gameincome.com/storage/backgrounds/icons8-origin_1627219200.svg');
INSERT INTO gameincome.services (id, name, slug, background) VALUES ('c97499a5-65f7-4944-bba9-13634fe65405', 'Xbox Games Store', 'xbox-games-store', 'https://api.gameincome.com/storage/backgrounds/icons8-xbox_1627219257.svg');