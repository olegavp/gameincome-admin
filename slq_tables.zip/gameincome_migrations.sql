create table migrations
(
    id        int unsigned auto_increment
        primary key,
    migration varchar(255) not null,
    batch     int          not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.migrations (id, migration, batch) VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (2, '2019_12_14_000001_create_personal_access_tokens_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (3, '2021_04_21_152710_create_users_ip_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (4, '2021_04_22_162908_create_sellers_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (5, '2021_04_22_162930_create_users_banned_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (6, '2021_04_24_070154_create_users_notifications_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (7, '2021_04_24_070840_create_global_notifications_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (8, '2021_04_24_153420_create_users_verify_emails_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (9, '2021_04_29_100324_create_main_page_headers_link_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (10, '2021_04_29_101724_create_main_page_slider_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (11, '2021_05_03_083129_create_news_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (12, '2021_05_03_084828_create_news_comments_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (13, '2021_05_03_213347_create_promo_codes_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (14, '2021_05_12_114747_create_report_files_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (15, '2021_05_12_130324_create_sellers_feedbacks_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (16, '2021_05_19_154850_create_users_balance_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (17, '2021_05_26_113404_create_transactions_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (18, '2021_06_01_152649_create_overviews_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (19, '2021_06_01_153928_create_categories_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (20, '2021_06_01_153928_create_genres_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (21, '2021_06_01_154338_create_platforms_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (22, '2021_06_01_154339_create_services_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (23, '2021_06_02_180952_create_main_page_inserts_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (24, '2021_06_02_181154_create_main_page_recommendations_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (25, '2021_06_02_181750_create_main_page_hits_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (26, '2021_06_02_183819_create_main_page_novelties_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (27, '2021_06_02_183835_create_main_page_sale_out_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (28, '2021_06_02_183840_create_main_page_overviews_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (29, '2021_06_02_183841_create_main_page_categories_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (30, '2021_07_14_193322_create_permission_tables', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (31, '2021_07_14_193333_create_general_appeals_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (32, '2021_07_14_193334_create_general_appeals_messages_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (33, '2021_07_14_193337_create_partnership_appeals_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (34, '2021_07_14_193338_create_partnership_appeals_messages_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (35, '2021_07_14_193339_create_tech_support_appeals_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (36, '2021_07_14_194000_create_tech_support_appeals_messages_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (37, '2021_07_14_203334_create_dispute_appeals_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (38, '2021_07_14_203337_create_dispute_appeals_messages_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (39, '2021_07_16_082041_create_jobs_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (40, '2021_07_16_083116_create_failed_jobs_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (41, '2021_07_17_145444_create_software_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (42, '2021_07_17_145451_create_games_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (43, '2021_07_17_145457_create_skins_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (44, '2021_07_17_145556_create_game_keys_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (45, '2021_07_17_145606_create_software_keys_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (46, '2021_07_18_201517_create_software_purchases_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (47, '2021_07_20_201518_create_game_purchases_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (48, '2021_07_25_150516_create_item_platform_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (49, '2021_07_25_150604_create_item_category_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (50, '2021_07_25_150648_create_item_genre_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (51, '2021_07_25_150701_create_item_service_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (52, '2021_07_30_162709_create_regions_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (53, '2021_10_04_143627_create_reviews_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (54, '2021_10_04_143657_create_reviews_views_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (55, '2021_10_04_151245_create_reviews_comments_table', 1);
INSERT INTO gameincome.migrations (id, migration, batch) VALUES (56, '2021_10_05_131210_create_main_page_reviews_table', 1);