create table software
(
    id                   char(36)                        not null
        primary key,
    steam_app_id         bigint                          not null,
    name                 varchar(255)                    not null,
    developer            varchar(255)                    null,
    publisher            varchar(255)                    null,
    short_description    text                            null,
    detailed_description text                            null,
    metacritic           varchar(255)                    null,
    release_date         varchar(255)                    null,
    link_to_media        varchar(255)                    null,
    pc_requirements      text                            null,
    header_image         text                            null,
    item_type            varchar(255) default 'software' not null
)
    collate = utf8mb4_unicode_ci;

create index item_type_index
    on software (item_type);

create index name_index
    on software (name);

create index steam_app_id
    on software (steam_app_id);

