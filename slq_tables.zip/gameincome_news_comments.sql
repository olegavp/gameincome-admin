create table news_comments
(
    id           char(36)                           not null
        primary key,
    news_id      char(36)                           not null,
    user_id      char(36)                           not null,
    parent_id    char(36)                           null,
    comment_text text                               not null,
    deleted_at   timestamp                          null,
    created_at   datetime default CURRENT_TIMESTAMP not null,
    updated_at   datetime default CURRENT_TIMESTAMP not null,
    constraint news_comments_news_id_foreign
        foreign key (news_id) references news (id),
    constraint news_comments_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index news_id_index
    on news_comments (news_id);

create index parent_id_index
    on news_comments (parent_id);

create index user_id_index
    on news_comments (user_id);

INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('01ac895f-5b28-41ca-b6e1-b388ab5cee6a', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'рапмиь', null, '2021-10-23 15:29:42', '2021-10-23 15:29:42');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('09778bad-ab35-421f-98fd-989bebd82c8e', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'унеурн', null, '2021-10-23 15:05:33', '2021-10-23 15:05:33');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('0a62e8e4-47a3-4d1f-9d11-fb2f5b75a049', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'b44caa02-9a78-42f0-b324-e4b804298733', 'asfsadfsdfsdfsdfg', null, '2021-10-11 20:30:44', '2021-10-11 20:30:44');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('2743b280-9fb4-4f5a-b0b5-5ce92668f4b6', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'fddfgfhfdg', null, '2021-10-23 15:12:21', '2021-10-23 15:12:21');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('3fce13d3-b5b5-472f-bd32-0244876b0fe7', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'sdfdsfs', null, '2021-10-23 15:11:49', '2021-10-23 15:11:49');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('50ce37c7-dc8d-44cd-a887-12866c298f85', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'fhdsfhsfh', null, '2021-10-11 20:19:02', '2021-10-11 20:19:02');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('50ceac87-c2b2-4d69-8cfe-a325e94c5946', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'sgfdsgdg', null, '2021-10-23 15:08:42', '2021-10-23 15:08:42');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('5d54f8cf-cef3-4822-a08b-51b057bdda98', 'cc1fe1d5-dab5-4bff-a6c7-56bcba732250', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', '9d308e37-3f66-4b75-8e9e-474d304f56ab', 'ыв', null, '2021-10-28 12:17:56', '2021-10-28 12:17:56');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('765b6e8e-6a7f-4e6b-a9e6-085d3f48ee42', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'унеурн', null, '2021-10-23 15:05:28', '2021-10-23 15:05:28');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('8bd85a8b-0dbf-4f63-b3a8-fba16e05a97c', '8472a62f-8139-42b5-8478-a08e79ca4670', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'ывыв', null, '2021-10-28 12:16:53', '2021-10-28 12:16:53');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('94a0f986-cddc-4ada-950f-ff6ce5afdc70', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'dghfh', null, '2021-10-11 20:20:06', '2021-10-11 20:20:06');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('99e5d020-e24a-4ff1-9cb4-b77231744608', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'f57305d7-db92-4262-a7c0-2fdf650d20f8', 'тим', null, '2021-10-23 15:29:54', '2021-10-23 15:29:54');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('9d308e37-3f66-4b75-8e9e-474d304f56ab', 'cc1fe1d5-dab5-4bff-a6c7-56bcba732250', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'вывыв', null, '2021-10-28 12:16:38', '2021-10-28 12:16:38');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('9ee03492-c822-4333-8b70-05f54ca74d88', 'cc1fe1d5-dab5-4bff-a6c7-56bcba732250', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', '9d308e37-3f66-4b75-8e9e-474d304f56ab', 'ывыв', null, '2021-10-28 12:17:45', '2021-10-28 12:17:45');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('a80cc116-dac4-4542-b8a5-151ac8f2dd12', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'унеурн', null, '2021-10-23 15:06:25', '2021-10-23 15:06:25');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('ac349ebe-e8f8-40cf-b909-63f42ce7e504', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'f57305d7-db92-4262-a7c0-2fdf650d20f8', 'tfhdfjyj', null, '2021-10-23 15:13:56', '2021-10-23 15:13:56');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('b44caa02-9a78-42f0-b324-e4b804298733', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'cvbfxgngfdg', null, '2021-10-11 20:19:18', '2021-10-11 20:19:18');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('b64fd7be-0024-467f-a81d-95797196d18f', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'gfdhtfgh', null, '2021-10-23 15:12:09', '2021-10-23 15:12:09');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('bdc74938-c8a3-4d2b-8837-83464b656e1e', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'арркпр', null, '2021-10-23 15:04:28', '2021-10-23 15:04:28');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('d262221e-9c7b-4d0b-aa5d-6b3ae3fe8f17', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'asfsadfsdf', null, '2021-10-11 20:30:24', '2021-10-11 20:30:24');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('d6ffc884-fca3-4e3c-b3ec-83243520bd5e', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'НОВЫЙ КОММЕНТ', null, '2021-10-23 15:08:56', '2021-10-23 15:08:56');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('e742a71f-0e9a-47fe-ae4c-caa27d633062', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'ac349ebe-e8f8-40cf-b909-63f42ce7e504', 'sdvdfbdbv', null, '2021-10-23 16:19:19', '2021-10-23 16:19:19');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('f57305d7-db92-4262-a7c0-2fdf650d20f8', '2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', null, 'арркпр', null, '2021-10-23 15:04:35', '2021-10-23 15:04:35');
INSERT INTO gameincome.news_comments (id, news_id, user_id, parent_id, comment_text, deleted_at, created_at, updated_at) VALUES ('f63a04c8-3452-482e-9141-b2b7b18900dd', 'cc1fe1d5-dab5-4bff-a6c7-56bcba732250', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', '9d308e37-3f66-4b75-8e9e-474d304f56ab', 'ыв', null, '2021-10-28 12:17:49', '2021-10-28 12:17:49');