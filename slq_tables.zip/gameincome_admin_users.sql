create table admin_users
(
    id                        bigint unsigned not null,
    name                      varchar(255)    not null,
    email                     varchar(255)    not null,
    email_verified_at         timestamp       null,
    password                  varchar(255)    not null,
    two_factor_secret         text            null,
    two_factor_recovery_codes text            null,
    remember_token            varchar(100)    null,
    created_at                timestamp       null,
    updated_at                timestamp       null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.admin_users (id, name, email, email_verified_at, password, two_factor_secret, two_factor_recovery_codes, remember_token, created_at, updated_at) VALUES (1, 'Valery', 'movleks78@gmail.com', null, '$2y$10$35PchcdBnRH.DawQczewouP6LNMD.x8M7VVYmhuGz9Z3qbQWQAgie', null, null, 'FHCEvKavdPBpv0pUqzQJdRyXbGMBLAl2reB5oSbgBZfjZqf5ADFQsgo1JvxI', '2021-08-06 14:30:03', '2021-08-21 00:07:21');