create table promo_codes
(
    id          char(36)                           not null
        primary key,
    name        varchar(50)                        not null,
    count       int      default 0                 not null,
    money       int                                null,
    finish_time datetime                           null,
    deleted_at  timestamp                          null,
    created_at  datetime default CURRENT_TIMESTAMP not null,
    updated_at  datetime default CURRENT_TIMESTAMP not null
)
    collate = utf8mb4_unicode_ci;

create index name_index
    on promo_codes (name);

INSERT INTO gameincome.promo_codes (id, name, count, money, finish_time, deleted_at, created_at, updated_at) VALUES ('d513a6be-2805-11ec-9621-0242ac130002', 'PROMO2021', 5, 1000000, null, null, '2021-10-08 10:06:49', '2021-10-08 10:06:49');
INSERT INTO gameincome.promo_codes (id, name, count, money, finish_time, deleted_at, created_at, updated_at) VALUES ('fd33c0fc-2805-11ec-9621-0242ac130002', 'NEWPROMO2021', 20, 250000, null, null, '2021-10-08 10:06:49', '2021-10-08 10:06:49');