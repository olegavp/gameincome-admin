create table sellers
(
    id         char(36)                           not null
        primary key,
    user_id    char(36)                           null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint sellers_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index user_id_index
    on sellers (user_id);

INSERT INTO gameincome.sellers (id, user_id, created_at, updated_at) VALUES ('2430f96e-58bf-4600-9f3b-11e6454d3b9b', '9250f2fb-924b-4f02-9a46-9be311f45213', '2021-09-21 15:08:54', '2021-09-21 15:08:54');
INSERT INTO gameincome.sellers (id, user_id, created_at, updated_at) VALUES ('d8cc9fc2-b098-4c71-891e-959af0297063', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', '2021-09-21 15:08:54', '2021-09-21 15:08:54');
INSERT INTO gameincome.sellers (id, user_id, created_at, updated_at) VALUES ('d8cc9fc2-b098-4c71-891e-959af0297064', '0e2090f0-d1da-4e55-ad25-0af0d2e85037', '2021-09-21 15:08:54', '2021-09-21 15:08:54');