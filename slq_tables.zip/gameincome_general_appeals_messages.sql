create table general_appeals_messages
(
    id         char(36)                           not null
        primary key,
    appeal_id  char(36)                           not null,
    user_id    char(36)                           null,
    admin_id   int                                null,
    text       text                               not null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint general_appeals_messages_appeal_id_foreign
        foreign key (appeal_id) references general_appeals (id)
)
    collate = utf8mb4_unicode_ci;

create index admin_id_index
    on general_appeals_messages (admin_id);

create index appeal_id_index
    on general_appeals_messages (appeal_id);

create index user_id_index
    on general_appeals_messages (user_id);

