create table platforms
(
    id   char(36)     not null
        primary key,
    name varchar(255) not null,
    slug varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.platforms (id, name, slug) VALUES ('340a183a-4507-42e8-a3db-45b1aaa143f2', 'Windows', 'windows');
INSERT INTO gameincome.platforms (id, name, slug) VALUES ('8cc4bf36-f9f4-4cca-b8b8-d84e6f461c4a', 'Linux', 'linux');
INSERT INTO gameincome.platforms (id, name, slug) VALUES ('b7589918-817b-4bfe-b65e-a5b1e51cf825', 'Mac', 'mac');