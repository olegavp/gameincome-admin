create table users_notifications
(
    id          char(36)                           not null
        primary key,
    user_id     char(36)                           null,
    type        varchar(100)                       null,
    name        varchar(100)                       null,
    description varchar(250)                       null,
    created_at  datetime default CURRENT_TIMESTAMP not null,
    updated_at  datetime default CURRENT_TIMESTAMP not null,
    constraint users_notifications_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index type_index
    on users_notifications (type);

create index user_id_index
    on users_notifications (user_id);

