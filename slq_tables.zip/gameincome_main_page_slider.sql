create table main_page_slider
(
    id                 char(36)     not null
        primary key,
    name               varchar(40)  not null,
    small_description  varchar(80)  not null,
    description        varchar(200) not null,
    link               varchar(255) null,
    text_on_button     varchar(30)  null,
    preview_background varchar(255) not null,
    background         varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.main_page_slider (id, name, small_description, description, link, text_on_button, preview_background, background) VALUES ('52f29fe1-f3b3-4163-b8c8-10bb1d486da9', 'Crysis 2', 'Crysis 2. Игра, которую вы ждали', 'Crysis 2 — легендарная серия игр. Миллионы проданных копий, сотни наград, и конечно фанаты, которые косплеят Гордона Фримена год за годом.', 'google.com', 'ПОДРОБНЕЕ', 'https://api.gameincome.com/storage/backgrounds/image 28_1627423692.png', 'https://api.gameincome.com/storage/backgrounds/image26_1627423692.png');
INSERT INTO gameincome.main_page_slider (id, name, small_description, description, link, text_on_button, preview_background, background) VALUES ('a2b0bb7f-dbef-4b77-b6bb-38fc6f9ff881', 'Ghost of Tsushima', 'Ghost of Tsushima. Игра, которую вы ждали', 'Ghost of Tsushima — легендарная серия игр. Миллионы проданных копий, сотни наград, и конечно фанаты, которые косплеят Гордона Фримена год за годом.', 'google.com', 'ПОДРОБНЕЕ', 'https://api.gameincome.com/storage/backgrounds/image 3_1627423440.png', 'https://api.gameincome.com/storage/backgrounds/image26_1627423440.png');
INSERT INTO gameincome.main_page_slider (id, name, small_description, description, link, text_on_button, preview_background, background) VALUES ('a9ff6b0a-484b-4501-bcca-31504031f4ae', 'Half-Life: Alyx', 'Half-Life: Alyx. Игра, которую вы ждали', 'Half Life — легендарная серия игр. Миллионы проданных копий, сотни наград, и конечно фанаты, которые косплеят Гордона Фримена год за годом.', 'google.com', 'ПОДРОБНЕЕ', 'https://api.gameincome.com/storage/backgrounds/Half-Life_Alyx_Coverart_1627423307.jpg', 'https://api.gameincome.com/storage/backgrounds/image26_1627423307.png');
INSERT INTO gameincome.main_page_slider (id, name, small_description, description, link, text_on_button, preview_background, background) VALUES ('b056e5c6-d6b7-4289-b5a0-9f7192bd9e57', 'Battle vs. Chess', 'Battle vs. Chess. Игра, которую вы ждали', 'Battle vs. Chess — легендарная серия игр. Миллионы проданных копий, сотни наград, и конечно фанаты, которые косплеят Гордона Фримена год за годом.', 'google.com', 'ПОДРОБНЕЕ', 'https://api.gameincome.com/storage/backgrounds/image 27_1627423584.png', 'https://api.gameincome.com/storage/backgrounds/image26_1627423584.png');
INSERT INTO gameincome.main_page_slider (id, name, small_description, description, link, text_on_button, preview_background, background) VALUES ('c81ded6a-3a85-48c6-be7f-38e052088f42', 'DEATHLOOP', 'DEATHLOOP. Игра, которую вы ждали', 'DEATHLOOP— легендарная серия игр. Миллионы проданных копий, сотни наград, и конечно фанаты, которые косплеят Гордона Фримена год за годом.', 'google.com', 'ПОДРОБНЕЕ', 'https://api.gameincome.com/storage/backgrounds/image 29_1627423751.png', 'https://api.gameincome.com/storage/backgrounds/image26_1627423751.png');