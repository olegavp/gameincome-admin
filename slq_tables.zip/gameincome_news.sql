create table news
(
    id                     char(36)                           not null
        primary key,
    name                   varchar(110)                       not null,
    description_on_3_words varchar(50)                        null,
    small_description      varchar(255)                       null,
    description            text                               null,
    type                   varchar(255)                       null,
    relation               varchar(255)                       null,
    small_background       varchar(255)                       null,
    background             varchar(255)                       null,
    deleted_at             timestamp                          null,
    created_at             datetime default CURRENT_TIMESTAMP not null,
    updated_at             datetime default CURRENT_TIMESTAMP not null
)
    collate = utf8mb4_unicode_ci;

create index description_on_3_words_index
    on news (description_on_3_words);

create index name_index
    on news (name);

create index small_description_index
    on news (small_description);

INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('2828ea9f-a317-485e-9eda-8b649ebdfb02', 'Apex Legends получила патч, улучшающий стабильность — шутер был неиграбелен больше недели', 'Respawn Ent. выпустила патч для Apex Legends.', 'Respawn Entertainment выпустила патч для онлайн-шутера Apex Legends. Он призван улучшить работу серверов и существенно снизить процент потери пакетов. Об этом сообщил комьюнити-менеджер компании Райан К. Райни в твиттере.', 'Игроки в Apex Legends жалуются на проблемы с соединением с момента выхода обновления 10.1 и старта коллекционного события «Эволюция». Многие пользователи испытывали трудности при попытках войти на серверы игры — в отдельных случаях ошибки могли длиться по несколько часов. Новый патч частично решает проблему, а более серьезные исправления Respawn обещает выпустить 22 сентября.

Ранее в сети появилась информация, что в «королевскую битву» от Respawn Entertainment могут добавить новую карту в тропическом стиле. По словам датамайнера, она будет добавлена в игру в одиннадцатом сезоне.', 'small', 'Apex Legends', 'http://admin.gameincome.com/storage/backgrounds/Без названия (4)_1632228852.jpg', 'http://admin.gameincome.com/storage/backgrounds/Без названия (5)_1632228852.jpg', null, '2021-09-21 12:53:35', '2021-09-21 12:54:12');
INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('2980aa13-8f9d-4ca0-b1ee-e2025b07d82b', 'Netflix представил первую VR‑игру — она полностью бесплатна', 'Netflix и первая VR‑игра', 'В App Lab для Oculus Quest стала доступна Eden Unearthed — первая VR-игра от Netflix. Она создана по аниме-сериалу Eden и доступна бесплатно для любого владельца шлема.', 'События игры разворачиваются в далеком будущем. Человечество исчезло, а мир населяют роботы. В роли одного из них игрок должен управлять мотоциклом и собирать яблоки, которые являются топливом для транспорта. Во время путешествия герой может делать остановки и узнавать подробности мира, а также соревноваться с другими игроками, для чего в тайтл введена система подсчета очков и глобальная таблица рекордов.

Eden Unearthed — не первая игра от Netflix. Ранее компания выпустила Stranger Things 3: The Game для ПК, консолей и мобильных устройств, а также Stranger Things: 1984 для смартфонов. Ранее в Польше началось тестирование раздела Netflix с видеоиграми, где доступны оба тайтла по мотивам «Очень странных дел».', 'small', 'Netflix', 'http://admin.gameincome.com/storage/backgrounds/netflix-16x9-1_1632228355.jpg', 'http://admin.gameincome.com/storage/backgrounds/Без названия (2)_1632228355.jpg', null, '2021-09-21 12:45:09', '2021-09-21 12:45:55');
INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('5220f483-a32e-4157-a730-a2d177e2ba45', 'Распродажа — скидки на Need for Speed Heat, L.A. Noire и South Park: The Stick of Truth', null, 'Скидки на Need for Speed Heat, L.A. Noire и South Park: The Stick of Truth', 'В цифровом магазине Microsoft Store обновились предложения еженедельной распродажи. До 27 сентября на площадке будут действовать скидки на Need for Speed Heat, L.A. Noire, South Park: The Stick of Truth и другие игры.
Распродажа в Microsoft Store:
Need for Speed Heat Deluxe — $17,5 вместо $70 (требуется подписка Gold);
Titanfall 2 Ultimate — $6 вместо $30 (требуется подписка Gold);
Assassin''s Creed IV Black Flag — $12 вместо $30 (требуется подписка Gold);
L.A. Noire — $20 вместо $40 (требуется подписка Gold);
South Park: The Stick of Truth — $10 вместо $30;
Steep — $12 вместо $30 (требуется подписка Gold);
Tom Clancy’s Ghost Recon Wildlands — $15 вместо $50 (требуется подписка Gold);
UFC 4 — $24 вместо $60;
XCOM 2 — $15 вместо $60 (требуется подписка Gold).
Ранее в Steam появились скидки на игры серии Call of Duty. До 28 сентября пользователи площадки Valve могут приобрести по сниженным ценам шутеры франшизы, а также дополнения для них.', 'big', 'Распродажа', 'http://admin.gameincome.com/storage/backgrounds/Без названия_1632229217.png', 'http://admin.gameincome.com/storage/backgrounds/Без названия_1632229217.png', null, '2021-09-21 12:59:47', '2021-09-21 13:00:17');
INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('5b17c871-6377-4405-9078-22e53e7b7908', 'Глава юридического отдела Blizzard покинула компанию', null, 'Клэр Харт освободила пост. Об этом сообщил портал PC Gamer.', 'Глава юридического отдела издательства Blizzard Entertainment Клэр Харт освободила пост. Об этом сообщил портал PC Gamer.

Харт трудилась в Blizzard Entertainment на протяжении трёх лет. По её словам, они «были полны неожиданных поворотов», но работать в издательстве всё равно «было честью» для юриста. Чем именно было вызвано решение Харт покинуть компанию и где она продолжит трудиться, пока неизвестно. Некоторые пользователи предположили, что это связано с недавним скандалом в Blizzard Entertainment — он повлёк увольнения многих ключевых разработчиков, а также руководителей издательства.

Ранее власти Калифорнии обратились в суд с иском к Activision Blizzard о дискриминации женщин. Ответ руководства компании не удовлетворил сотрудников студии, которые устроили серию забастовок. В сентябре Комиссия по ценным бумагам США инициировала проверку, чтобы выяснить, как руководство Activision Blizzard расследовало жалобы сотрудников на домогательства и дискриминацию.', 'big', 'Blizzard', 'http://admin.gameincome.com/storage/backgrounds/Без названия (6)_1632229052.jpg', 'http://admin.gameincome.com/storage/backgrounds/Без названия (6)_1632229052.jpg', null, '2021-09-21 12:57:11', '2021-09-21 12:57:32');
INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('67e05ce8-fb55-477a-80f1-2f88b0bf0f96', 'Для Valve мы просто дойные коровы» — игрок в Dota 2 попросил не продавать арканы через Battle Pass', 'Просто дойные коровы', 'Игрок в Dota 2 под никнеймом iamlen07 пожаловался на несправедливость способа получения аркан в MOBA от Valve. По его мнению, предметы повышенной редкости не должны быть частью Battle Pass.', 'Система Battle Pass вынуждает геймеров уделять большее внимание игре в конкретные периоды действия. Если пользователь не имеет возможности купить большое количество уровней и регулярно играть, то может лишиться шанса получить аркану на любимого героя.
В ночь на 17 сентября в Dota 2 вышло обновление с компендиумом The International 10 (2021) — для всех игроков оно является бесплатным. В игре также обнаружили намеки на аркану для Luna и персону Mirana.', 'small', 'Dota 2', 'http://admin.gameincome.com/storage/backgrounds/dota-bp10-share-img_1632227937.png', 'http://admin.gameincome.com/storage/backgrounds/15907004431094815823_1632227937.jpg', null, '2021-09-21 12:37:10', '2021-09-21 12:38:57');
INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('8472a62f-8139-42b5-8478-a08e79ca4670', 'В Steam началась распродажа игр серии Call of Duty', null, 'В  Steam появились скидки на игры серии Call of Duty.', 'В цифровом магазине Steam появились скидки на игры серии Call of Duty. До 28 сентября пользователи площадки Valve могут приобрести по сниженным ценам шутеры франшизы, а также дополнения для них.
Распродажа игр серии Call of Duty в Steam:
Call of Duty Franchise Collection — ₽23 117 вместо ₽44 460;
Call of Duty: WWII — ₽999 вместо ₽1 999;
Call of Duty: Infinite Warfare — ₽999 вместо ₽1 999;
Call of Duty: Black Ops III — ₽1 199 вместо ₽1 999;
Call of Duty: World at War — ₽674 вместо ₽899;
Call of Duty: Modern Warfare — ₽449 вместо ₽899;
Call of Duty: Modern Warfare 2 — ₽674 вместо ₽899;
Call of Duty: Modern Warfare 3 — ₽899 вместо ₽1 799.
Релиз Call of Duty: Vanguard состоится 5 ноября. Игра выйдет на ПК, PlayStation 5 и 4, а также на Xbox One и Xbox Series. Ранее сообщалось, что пользователи, заблокированные в Call of Duty: Warzone, не смогут сыграть в новый шутер Activision.', 'big', 'Распродажа', 'http://admin.gameincome.com/storage/backgrounds/Без названия (7)_1632229345.jpg', 'http://admin.gameincome.com/storage/backgrounds/images_1632229345.jpg', null, '2021-09-21 13:01:50', '2021-09-21 13:02:25');
INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('cc1fe1d5-dab5-4bff-a6c7-56bcba732250', 'S1mple про отказ переходить в SK Gaming: «Я не был уверен, что мы будем всех разносить»', 'S1mple и отказ переходить в SK Gaming', 'Снайпер Natus Vincere Александр s1mple Костылев объяснил, почему в 2018 году не захотел переходить в бразильский состав SK Gaming / MIBR по CS:GO. По его словам, в то время он не был уверен в силе и перспективах команды.', 'Александр s1mple Костылев:
«Почему не перешел в SK Gaming? Я не знаю, чувак, я не был полностью уверен в этом. Почему? Я уже жил в Лос-Анджелесе, и я не был уверен, что мы будем всех разносить».

Ранее СЕО Natus Vincere Евгений Золотарёв заявил, что за все пять лет Костылева в украинском клубе была только одна ситуация, когда игрок мог покинуть команду. По его словам, это было связано с эмоциональным поведением киберспортсмена после турнира. Костылев действительно рассматривал вариант перейти в MIBR, так как там играли Габриэль FalleN Толедо и Эпитасио TACO де Мело, которые на тот момент были действующими двукратными чемпионами мира.', 'small', 'CS:GO', 'http://admin.gameincome.com/storage/backgrounds/maxresdefault_1632228624.jpg', 'http://admin.gameincome.com/storage/backgrounds/Без названия (3)_1632228624.jpg', null, '2021-09-21 12:49:25', '2021-09-21 12:50:24');
INSERT INTO gameincome.news (id, name, description_on_3_words, small_description, description, type, relation, small_background, background, deleted_at, created_at, updated_at) VALUES ('ee17b59a-3750-43c0-8d6d-67714aaf6b4f', 'RAMZES: «Я был таким спокойным, пока не начал много играть в Dota 2»', 'Долгая игра в Dota 2', 'Российский киберспортсмен Роман RAMZES666 Кушнарёв обратил внимание, что чем больше он играет в Dota 2, тем больше начинает нервничать. Об этом геймер рассказал во время общения со зрителями на Twitch.', '«Я был таким спокойным, пока не начал дофига играть в Dota 2. Когда ты начинаешь дофига играть в Dota 2, ты становишься эмоционально нестабильным».

Ранее российский стример Никита Daxak Кузьмин рассказал, что Игорь iLTW Филатов испортил ему две игры в матчмейкинге, так как был в плохом настроении. В частности, он разбил вещи на герое в середине матча и взял неподходящего персонажа для первой позиции, что привело к поражению.', 'small', 'Dota 2', 'http://admin.gameincome.com/storage/backgrounds/Без названия_1632228164.jpg', 'http://admin.gameincome.com/storage/backgrounds/Без названия (1)_1632228164.jpg', null, '2021-09-21 12:41:27', '2021-09-21 12:42:44');