create table software_keys
(
    id                 char(36)                             not null
        primary key,
    seller_id          char(36)                             not null,
    item_id            char(36)                             not null,
    `key`              varchar(255)                         not null,
    seller_price       bigint                               not null,
    service_price      bigint                               not null,
    seller_sale_price  bigint                               null,
    service_sale_price bigint                               null,
    region_id          char(36)                             not null,
    bought             tinyint(1) default 0                 not null,
    deleted_at         timestamp                            null,
    created_at         datetime   default CURRENT_TIMESTAMP not null,
    updated_at         datetime   default CURRENT_TIMESTAMP not null,
    constraint software_keys_seller_id_foreign
        foreign key (seller_id) references sellers (id)
)
    collate = utf8mb4_unicode_ci;

create index item_id_index
    on software_keys (item_id);

create index key_index
    on software_keys (`key`);

create index region_id_index
    on software_keys (region_id);

create index seller_id_index
    on software_keys (seller_id);

