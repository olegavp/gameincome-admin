create table regions
(
    id   char(36)     not null
        primary key,
    name varchar(255) not null,
    slug varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

create index name_index
    on regions (name);

create index slug_index
    on regions (slug);

INSERT INTO gameincome.regions (id, name, slug) VALUES ('9d117fb3-b944-4894-a00b-810f593effe2', 'Россия', 'Russia');
INSERT INTO gameincome.regions (id, name, slug) VALUES ('c82190cc-c82e-4782-ad23-89f2e4ee93fb', 'Европа', 'Europe');