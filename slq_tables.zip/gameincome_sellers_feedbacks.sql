create table sellers_feedbacks
(
    id         char(36)                           not null
        primary key,
    seller_id  char(36)                           not null,
    user_id    char(36)                           not null,
    key_id     char(36)                           not null,
    rate       int                                not null,
    comment    text                               not null,
    item_type  varchar(255)                       not null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint sellers_feedbacks_seller_id_foreign
        foreign key (seller_id) references sellers (id),
    constraint sellers_feedbacks_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index item_type_index
    on sellers_feedbacks (item_type);

create index key_id
    on sellers_feedbacks (key_id);

create index rate_id
    on sellers_feedbacks (rate);

create index seller_id
    on sellers_feedbacks (seller_id);

create index user_id
    on sellers_feedbacks (user_id);

INSERT INTO gameincome.sellers_feedbacks (id, seller_id, user_id, key_id, rate, comment, item_type, created_at, updated_at) VALUES ('9520fbcf-f31b-4dce-a449-c857f2afd7a4', 'd8cc9fc2-b098-4c71-891e-959af0297063', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', '9130f998-6514-4da3-872c-d35d4db1d29b', 1, 'Ключ подошёл, на сервисе честные продавцы!', 'game', '2021-09-22 20:39:10', '2021-09-22 20:39:10');
INSERT INTO gameincome.sellers_feedbacks (id, seller_id, user_id, key_id, rate, comment, item_type, created_at, updated_at) VALUES ('d7f99d34-b500-4038-b6f8-4656456101c6', 'd8cc9fc2-b098-4c71-891e-959af0297063', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', '1de070c5-f946-4b66-b5ce-2c7b4fde97d1', 0, 'сиаитапра', 'game', '2021-10-16 06:39:33', '2021-10-16 06:39:33');