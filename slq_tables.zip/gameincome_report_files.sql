create table report_files
(
    id         char(36)                           not null
        primary key,
    user_id    char(36)                           null,
    path       varchar(255)                       not null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint report_files_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index path_index
    on report_files (path);

create index user_id_index
    on report_files (user_id);

