create table users_balance
(
    id                char(36)                    not null
        primary key,
    user_id           char(36)                    not null,
    overall_balance   bigint unsigned default '0' not null,
    pending_balance   bigint unsigned default '0' not null,
    available_balance bigint unsigned default '0' not null,
    constraint users_balance_user_id_unique
        unique (user_id),
    constraint users_balance_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.users_balance (id, user_id, overall_balance, pending_balance, available_balance) VALUES ('6218aa12-11ea-4f6f-ad3b-d45dcf7f2f66', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 1250000, 0, 1250000);
INSERT INTO gameincome.users_balance (id, user_id, overall_balance, pending_balance, available_balance) VALUES ('6218aa12-11ea-4f6f-ad3b-d45dcf7f2f67', '0e2090f0-d1da-4e55-ad25-0af0d2e85037', 0, 0, 0);
INSERT INTO gameincome.users_balance (id, user_id, overall_balance, pending_balance, available_balance) VALUES ('6218aa12-11ea-4f6f-ad3b-d45dcf7f2f68', '9250f2fb-924b-4f02-9a46-9be311f45213', 0, 0, 0);