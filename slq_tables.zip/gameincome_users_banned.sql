create table users_banned
(
    id         char(36)                           not null
        primary key,
    user_id    char(36)                           null,
    cause      varchar(255)                       null,
    deleted_at timestamp                          null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint users_banned_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index cause_index
    on users_banned (cause);

create index user_id_index
    on users_banned (user_id);

