create table game_purchases
(
    id         char(36)                           not null
        primary key,
    user_id    char(36)                           not null,
    seller_id  char(36)                           not null,
    key_id     char(36)                           not null,
    item_id    char(36)                           not null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint game_purchases_item_id_foreign
        foreign key (item_id) references games (id),
    constraint game_purchases_key_id_foreign
        foreign key (key_id) references game_keys (id),
    constraint game_purchases_seller_id_foreign
        foreign key (seller_id) references sellers (id),
    constraint game_purchases_user_id_foreign
        foreign key (user_id) references users (id)
)
    collate = utf8mb4_unicode_ci;

create index item_id
    on game_purchases (item_id);

create index key_id_index
    on game_purchases (key_id);

create index seller_id_index
    on game_purchases (seller_id);

create index user_id_index
    on game_purchases (user_id);

INSERT INTO gameincome.game_purchases (id, user_id, seller_id, key_id, item_id, created_at, updated_at) VALUES ('943f17b7-e16d-4975-8d74-381aa35a32f0', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'd8cc9fc2-b098-4c71-891e-959af0297063', '1de070c5-f946-4b66-b5ce-2c7b4fde97d1', '1f2f0e14-8a7d-4c40-a832-0b59d080d772', '2021-09-22 20:37:55', '2021-09-22 20:37:55');
INSERT INTO gameincome.game_purchases (id, user_id, seller_id, key_id, item_id, created_at, updated_at) VALUES ('943f17b7-e16d-4975-8d74-381aa35a32f9', '0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'd8cc9fc2-b098-4c71-891e-959af0297063', '9130f998-6514-4da3-872c-d35d4db1d29b', '598fb139-58e6-4583-b695-e4073a98fad4', '2021-09-22 20:37:55', '2021-09-22 20:37:55');