create table reviews_views
(
    id        char(36)         not null
        primary key,
    review_id char(36)         not null,
    count     bigint default 0 not null,
    constraint reviews_views_review_id_foreign
        foreign key (review_id) references reviews (id)
)
    collate = utf8mb4_unicode_ci;

create index review_id_index
    on reviews_views (review_id);

INSERT INTO gameincome.reviews_views (id, review_id, count) VALUES ('c3b23d38-2808-11ec-9621-0242ac130002', '54db6bc2-26a1-11ec-9621-0242ac130002', 7);
INSERT INTO gameincome.reviews_views (id, review_id, count) VALUES ('fc5196da-2807-11ec-9621-0242ac130002', '54db688e-26a1-11ec-9621-0242ac130002', 16);
INSERT INTO gameincome.reviews_views (id, review_id, count) VALUES ('fc519a4a-2807-11ec-9621-0242ac130002', '54db6fc8-26a1-11ec-9621-0242ac130002', 127);
INSERT INTO gameincome.reviews_views (id, review_id, count) VALUES ('fc519b44-2807-11ec-9621-0242ac130002', '54db6c9e-26a1-11ec-9621-0242ac130002', 11);
INSERT INTO gameincome.reviews_views (id, review_id, count) VALUES ('fc519c0c-2807-11ec-9621-0242ac130002', 'e8a8a92e-26a0-11ec-9621-0242ac130002', 0);
INSERT INTO gameincome.reviews_views (id, review_id, count) VALUES ('fc519dba-2807-11ec-9621-0242ac130002', '54db6ac8-26a1-11ec-9621-0242ac130002', 7);