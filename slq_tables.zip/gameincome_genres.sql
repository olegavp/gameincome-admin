create table genres
(
    id   char(36)     not null
        primary key,
    name varchar(255) not null,
    slug varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.genres (id, name, slug) VALUES ('03158337-fce1-4250-a69a-7344ea9b2907', 'Кооператив (общий экран)', 'kooperativ-obshhii-ekran');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('0b227d37-862b-46d1-92de-c5b17a226767', 'Предметы для SteamVR', 'predmety-dlya-steamvr');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('15f52cd8-0cde-499a-9115-5a0b7c9c97be', 'Remote Play на телевизоре', 'remote-play-na-televizore');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('203a60c5-b601-4392-9023-9ab09d9d8c2b', 'Виртуальная реальность', 'virtualnaya-realnost');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('26a80022-9b12-4022-ad41-0774d12af089', 'Против игроков (по сети)', 'protiv-igrokov-po-seti');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('2b2cbce9-5b0d-41ad-b37a-1d9ffb4bf43a', 'Общий экран', 'obshhii-ekran');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('2df13770-41f3-4557-8cff-907429f02220', 'Включает Source SDK', 'vklyucaet-source-sdk');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('2fbd935c-bb14-48fd-8727-6aac3e15ac6f', 'Remote Play Together', 'remote-play-together');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('3758138d-d3c2-42df-93b0-41d881a32387', 'Достижения Steam', 'dostizeniya-steam');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('3acc515e-26fc-45c0-b267-eb3d6678b393', 'Для одного игрока', 'dlya-odnogo-igroka');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('3af2eb5b-d01a-4349-9fcf-73b46d6a75ae', 'Кооперативная игра', 'kooperativnaya-igra');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('58617121-28b4-4786-981b-2c481b80dd2b', 'Имеется античит Valve', 'imeetsya-anticit-valve');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('670aa36d-1835-49b5-8102-31dc48088cf2', 'Покупки внутри приложения', 'pokupki-vnutri-prilozeniya');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('6b6c036b-72d5-4f7c-9e72-378318b4dabc', 'Контроллер (полностью)', 'kontroller-polnostyu');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('6f0fe068-f8fd-423c-a930-2958c6cfa09b', 'Доски почета Steam', 'doski-poceta-steam');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('7bb2fdf8-34a8-46df-aa96-be9dea4b163f', 'Steam Cloud', 'steam-cloud');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('7d2be313-745b-416a-8df4-9ba529708ee2', 'Имеются комментарии', 'imeyutsya-kommentarii');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('82117e01-660b-44da-99aa-ba278c1a49dc', 'Кооператив (по сети)', 'kooperativ-po-seti');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('964d1575-d586-4239-9855-29d5dee9ab0d', 'Против игроков (общий экран)', 'protiv-igrokov-obshhii-ekran');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('986e14ea-e788-4bf7-b350-b115254de37d', 'MMO', 'mmo');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('a157ae88-693e-4881-b5fb-6b4f74e3a5f7', 'Коллекционные карточки', 'kollekcionnye-kartocki');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('af843068-84b2-4bf8-9a29-ea218f20afc7', 'Против игроков', 'protiv-igrokov');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('b32b4f54-8ef3-49b5-8f8e-8d697163d695', 'Remote Play на телефоне', 'remote-play-na-telefone');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('b3b836f6-0fe4-4f96-814e-c9e9ef1ea1e2', 'Кооператив (LAN)', 'kooperativ-lan');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('b44325b2-4ec7-4070-af5b-2b9fa844cf0c', 'Для нескольких игроков', 'dlya-neskolkix-igrokov');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('b99091e6-9592-4e82-8b2f-ded8753712bc', 'Контроллер (частично)', 'kontroller-casticno');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('cc308896-3855-46e4-a9c4-1b62b11de5ef', 'Включает редактор уровней', 'vklyucaet-redaktor-urovnei');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('df0bb42d-b8a2-4cee-ae89-43e33116636c', 'Кроссплатформенная игра', 'krossplatformennaya-igra');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('df15ee30-930e-4743-9f33-cdac821d2c56', 'Мастерская Steam', 'masterskaya-steam');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('e31d3d22-e556-49d7-a108-5473a3069fd7', 'Против игроков (LAN)', 'protiv-igrokov-lan');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('e846b251-59cc-4e75-97ec-e280822740d0', 'Имеются субтитры', 'imeyutsya-subtitry');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('f925b69f-8397-4e1e-bbe8-3a8afecf5790', 'Remote Play на планшете', 'remote-play-na-plansete');
INSERT INTO gameincome.genres (id, name, slug) VALUES ('fc2e7ea8-c8f5-4612-8a2e-d686f17c421c', 'Статистика', 'statistika');