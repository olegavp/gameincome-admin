create table main_page_categories
(
    id          char(36)     not null
        primary key,
    category_id char(36)     not null,
    background  varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

create index category_id_index
    on main_page_categories (category_id);

INSERT INTO gameincome.main_page_categories (id, category_id, background) VALUES ('53bce04e-6baa-4212-9f14-eb47f4273739', 'f9159b8c-a7d4-44d1-a561-df6c64c47303', 'https://api.gameincome.com/storage/backgrounds/RPG 1_1627934665.png');
INSERT INTO gameincome.main_page_categories (id, category_id, background) VALUES ('b981f183-30b6-43e5-b651-936ea0a04eae', '1f9840e2-8993-4d92-a2ea-a4ba42444fee', 'https://api.gameincome.com/storage/backgrounds/Adventure 1_1627934503.png');
INSERT INTO gameincome.main_page_categories (id, category_id, background) VALUES ('bb70a732-9fec-4973-92a8-a5a640e85183', '3c4e50b3-f2b7-489f-b21b-8d2693b493bf', 'https://api.gameincome.com/storage/backgrounds/Racing 1_1627934431.png');
INSERT INTO gameincome.main_page_categories (id, category_id, background) VALUES ('ce37a0d3-0c9b-41bf-a316-41a1bf95f016', '05159f73-90bb-474c-a974-de30826e2e32', 'https://api.gameincome.com/storage/backgrounds/Horror 1_1627934585.png');
INSERT INTO gameincome.main_page_categories (id, category_id, background) VALUES ('ea99d30a-522f-40ed-8c43-1abad1c55c88', 'f9159b8c-a7d4-44d1-a561-df6c64c47303', 'https://api.gameincome.com/storage/backgrounds/Action 1_1627934303.png');
INSERT INTO gameincome.main_page_categories (id, category_id, background) VALUES ('f93438be-7449-4c7a-a7e8-042582ca0d42', '8fa91de4-dc32-42a5-a4bb-ae9eabfda639', 'https://api.gameincome.com/storage/backgrounds/Strategy 1_1627934357.png');