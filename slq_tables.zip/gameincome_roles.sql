create table roles
(
    id         bigint unsigned auto_increment
        primary key,
    name       varchar(255) not null,
    guard_name varchar(255) not null,
    created_at timestamp    null,
    updated_at timestamp    null,
    constraint roles_name_guard_name_unique
        unique (name, guard_name)
)
    collate = utf8mb4_unicode_ci;

INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (1, 'Писатель новостей', 'web', '2021-08-06 14:04:37', '2021-08-06 14:04:37');
INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (2, 'Администратор', 'web', '2021-08-06 14:04:44', '2021-08-06 14:04:44');
INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (3, 'Модератор', 'web', '2021-08-06 14:04:55', '2021-08-06 14:04:55');
INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (4, 'Писатель обзоров', 'web', '2021-08-06 14:05:19', '2021-08-06 14:05:19');
INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (5, 'Поддержка по вопросам общего назначения', 'web', '2021-08-06 14:19:48', '2021-08-06 14:19:48');
INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (6, 'Поддержка по вопросам сотрудничества', 'web', '2021-08-06 14:19:57', '2021-08-06 14:19:57');
INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (7, 'Поддержка по вопросам споров', 'web', '2021-08-06 14:20:07', '2021-08-06 14:20:07');
INSERT INTO gameincome.roles (id, name, guard_name, created_at, updated_at) VALUES (8, 'Поддержка по вопросам технической части', 'web', '2021-08-06 14:20:15', '2021-08-06 14:20:15');