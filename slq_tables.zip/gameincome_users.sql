create table users
(
    id         char(36)                           not null
        primary key,
    name       varchar(100)                       not null,
    surname    varchar(100)                       null,
    email      varchar(255)                       not null,
    password   varchar(255)                       not null,
    nickname   varchar(100)                       null,
    avatar     text                               null,
    code       int                                null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    updated_at datetime default CURRENT_TIMESTAMP not null,
    constraint users_email_unique
        unique (email)
)
    collate = utf8mb4_unicode_ci;

create index code_index
    on users (code);

create index nickname_index
    on users (nickname);

INSERT INTO gameincome.users (id, name, surname, email, password, nickname, avatar, code, created_at, updated_at) VALUES ('0e2090f0-d1da-4e55-ad25-0af0d2e85036', 'Artyom1155', 'Yun44', 'yunartyom@mail.ru', '$2y$10$QezreJpVq39/Lra7Xetste0u7DBeH4V9GUl4zmp3kwEkKXt.dRoI.', 'yunartyom441', 'https://api.gameincome.com/storage/avatars/avatar/image_2021-10-20_13-30-30_1634914669.png', null, '2021-07-14 19:53:43', '2021-10-25 13:48:09');
INSERT INTO gameincome.users (id, name, surname, email, password, nickname, avatar, code, created_at, updated_at) VALUES ('0e2090f0-d1da-4e55-ad25-0af0d2e85037', 'Vitaly', 'Ivanov', 'vitaly@mail.ru', '$2y$10$QezreJpVq39/Lra7Xetste0u7DBeH4V9GUl4zmp3kwEkKXt.dRoI.', 'The best seller', 'https://img.championat.com/c/900x900/news/big/m/a/kogda-zhdat-gta-6_1626768455360083277.jpg', null, '2021-07-14 19:53:43', '2021-09-15 10:22:43');
INSERT INTO gameincome.users (id, name, surname, email, password, nickname, avatar, code, created_at, updated_at) VALUES ('9250f2fb-924b-4f02-9a46-9be311f45213', 'Dmitry', 'Smirnov', 'dmitry@mail.ru', '$2y$10$QezreJpVq39/Lra7Xetste0u7DBeH4V9GUl4zmp3kwEkKXt.dRoI.', 'You need it ^^)', 'https://icdn.lenta.ru/images/2021/04/27/16/20210427163138131/detail_9b31eaf4376cdff03e0ba1bcaa826a01.jpg', null, '2021-07-14 19:53:43', '2021-09-15 10:22:43');