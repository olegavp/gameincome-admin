create table main_page_sale_out
(
    id        char(36)     not null
        primary key,
    item_id   char(36)     not null,
    item_type varchar(255) not null
)
    collate = utf8mb4_unicode_ci;

create index item_id_index
    on main_page_sale_out (item_id);

create index item_type_index
    on main_page_sale_out (item_type);

INSERT INTO gameincome.main_page_sale_out (id, item_id, item_type) VALUES ('38ba45ea-b4ad-4973-b2ac-44d998c730df', '1f2f0e14-8a7d-4c40-a832-0b59d080d772', 'game');
INSERT INTO gameincome.main_page_sale_out (id, item_id, item_type) VALUES ('6698cf62-d3a8-4ac5-9bf7-bf987efd7b2b', '24bcefd1-ac57-40c0-b514-c301f7f35b51', 'game');
INSERT INTO gameincome.main_page_sale_out (id, item_id, item_type) VALUES ('c7cd7986-0b29-44f6-8f82-14fe25ea2d1f', '598fb139-58e6-4583-b695-e4073a98fad4', 'game');
INSERT INTO gameincome.main_page_sale_out (id, item_id, item_type) VALUES ('d41f7913-bea3-4ae7-a600-15a433ad5cea', '37a3d4f3-624c-493d-9499-f77a6dedc238', 'game');
INSERT INTO gameincome.main_page_sale_out (id, item_id, item_type) VALUES ('d822a1df-151b-4c8a-87f2-c044b28d8e5a', 'e8e37c54-0a45-47ce-b332-83f85e728799', 'game');
INSERT INTO gameincome.main_page_sale_out (id, item_id, item_type) VALUES ('f04a6198-cb8d-4cf5-8e15-c788a50dca18', '2c4e2d1e-014c-4ba2-846f-925227cd8095', 'game');